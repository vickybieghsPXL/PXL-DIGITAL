# Bugra Akdag - 1 TIN F
from random import randint


def bereken_basisscore(naam, geboortjejaar):
    waardes = []
    posities = []
    basisscore = 0
    for index in range(len(naam)):
        if naam[index] in "cinema":
            posities.append(index + 1)
            waardes.append(ord(naam[index]))
    for i in range(len(waardes)):
        basisscore += int(waardes[i]) * int(posities[i])
    basisscore += geboortjejaar
    return basisscore


namen = []
basisscore = []
scores = []

naam = input("Wat is jouw naam? ")
while naam != "xx" and naam != "qqq":
    geboorte_jaar = int(input("Wat is jouw geboortejaar? "))
    aantal_bezoeken = int(input("Hoevaak per maand kom je naar kinepolis? (1 = weinig, 2 = matig, 3 = veel) "))
    versnappering = input("Welke versnapering nuttig je in kinepolis? (P = Popcorn, C = chips, N = niets) ")
    basisscore_main = bereken_basisscore(naam, geboorte_jaar)

    print("Basisscore:", basisscore_main)

    if aantal_bezoeken == 1:
        score = basisscore_main * 0.5
    elif aantal_bezoeken == 2:
        score = basisscore_main * 2
    else:
        score = basisscore_main * 3

    if aantal_bezoeken == 1 and versnappering == "N":
        score -= 1050

    namen.append(naam)
    basisscore.append(basisscore_main)
    scores.append(score)
    print()

    naam = input("Wat is jouw naam? ")

hoogste_score = max(scores)
winnaar = scores.index(hoogste_score)
getal = randint(1, 9999)

while getal % 10 == 1 or (getal < 5000 and getal % 2 == 1):
    getal = randint(1000, 9999)
som_cijfers = 0
for j in str(getal):
    som_cijfers += int(j)

print("{} : Jij hebt gewonnen!".format(namen[winnaar]))
print("Jouw score is: {}".format(scores[winnaar]))
print("Het random gegenereerd getal is {}".format(getal))
print("{}, jij wint hierbij {} filmtickets".format(namen[winnaar], som_cijfers))
