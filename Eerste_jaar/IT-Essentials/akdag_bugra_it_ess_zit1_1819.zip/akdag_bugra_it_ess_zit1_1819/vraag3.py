# Bugra Akdag - 1 TIN F
def convert_to_bin(getal):
    bin = []
    binair_getal = []
    kopie_getal = getal

    while kopie_getal > 0:              #voor de comma
        bin.append(int(kopie_getal % 2))
        kopie_getal //= 2
    bin.reverse()
    comma_getal = getal - (getal // 1)

    bin2 = []                           #na de comma
    while comma_getal != 0:
        comma_getal *= 2
        if comma_getal >= 1:
            bin2.append(1)
            comma_getal -= 1
        else:
            bin2.append(0)

    for i in range(len(bin)):           #voor de comma vullen in een string
        binair_getal.append(bin[i])
    if len(bin2) != 0:
        binair_getal.append(",")
        bin2.reverse()
        laatste_een = bin2.index(1)
        bin2.reverse()
        maximum = 10
        aantal = len(bin2) - laatste_een

        if aantal > maximum:
            aantal = maximum
        for j in range(aantal):
            binair_getal.append(bin2[j])    #na de comma vullen in een string

    return binair_getal


getal = float(input("Geef een getal in "))
if getal % 1 == 0:
    getal = int(getal)                      #voor een mooie uitdruk ook al gaat het om een geheel getal
print("De binaire voorstelling van getal {} is ".format(getal), end="")
uitkomst = convert_to_bin(getal)
for i in uitkomst:
    print(i, end="")
