// naam: 

window.addEventListener("load", handleWindowload);

function handleWindowload() {
    let url = 'http://localhost:3000/country/';
}

function handleGetShips() {
    let url = 'http://localhost:3000/ship/';
}
