# Bugra Akdag - 1 TIN F
def print_lijst_a(lijst):
    for j in range(len(lijst)):
        print(lijst[j])


def print_lijst_s(artikels_, hoeveelheid):
    for k in range(len(artikels_)):
        print("Product {} te bestellen: {} stuks".format(artikels_[k], hoeveelheid[k]))


artikels = ["S-kaftE34-5-100", "S-DVD345-1-124", "A-penD34-125", "S-boekX33-3-256", "A-bal34-145", "S-boekZ34-2-26",
            "A-ballon34-15"]
a_artikels = []
bij_te_bestellen_artikels = []
bij_te_bestellen_hoeveelheid = []

for i in range(len(artikels)):
    artikels_in_voorraad = int(input("Geef het aantal artikels in voorraad van het artikel {}: ".format(artikels[i])))
    artikel_info = artikels[i].split("-")

    if artikel_info[0] == "A":
        while artikels_in_voorraad > int(artikel_info[2]):
            print("Foute ingave! Zoveel artikels kunnen niet in voorraad zijn.")
            artikels_in_voorraad = int(
                input("Opnieuw: Geef het aantal artikels in voorraad van het artikel {}: ".format(artikels[i])))

        if artikels_in_voorraad > 0:
            artikel_info[2] = artikels_in_voorraad
            a_artikels.append(artikel_info[0] + "-" + artikel_info[1] + "-" + str(artikel_info[2]))

    if artikel_info[0] == "S":
        if artikels_in_voorraad < int(artikel_info[3]):
            bij_te_bestellen = int(artikel_info[3]) - artikels_in_voorraad
            bij_te_bestellen = int(bij_te_bestellen // int(artikel_info[2]) + 0.5) * int(artikel_info[2])
            if (int(artikel_info[3]) - artikels_in_voorraad) % int(artikel_info[2]) == 1:
                bij_te_bestellen += int(artikel_info[2])
            bij_te_bestellen_artikels.append(artikels[i])
            bij_te_bestellen_hoeveelheid.append(bij_te_bestellen)

print()
print("Lijst van bij te bestellen producten")
print_lijst_s(bij_te_bestellen_artikels, bij_te_bestellen_hoeveelheid)
print()
print("Lijst van de actie artikelen")
print_lijst_a(a_artikels)
